package com.example.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.Cart;
import com.example.demo.service.CartService;


@CrossOrigin(origins ="null", allowedHeaders = "*")
@RestController
@RequestMapping("/crt")
public class CartController {
	
	@Autowired
	CartService Cartservice;

	@GetMapping("/carts")
	private List<Cart> getAllCart() {
		return Cartservice.getAllCarts();
	}
	
	@PostMapping("/cart_save")
	private Cart saveCart(@RequestBody Cart Cart1) {
		Cartservice.saveOrUpdate(Cart1);
		return Cart1;
	}
	

	@GetMapping("/product/{product_id}")
	private Cart getCart(@PathVariable("product_id") int CartId) {
		return Cartservice.getCartById(CartId);
	}
	
	
	
	
	@DeleteMapping("/product/{product_id}")
	private void deleteProducts(@PathVariable("product_id") int CartId) {
		Cartservice.delete(CartId);
	}
	
	

	
}