package com.example.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.modal.Cart;

public interface CartRepo extends JpaRepository<Cart, Integer> {
	
	@Query(value = "select * from cart where user_id=:userId", nativeQuery=true)
	public Cart getByUserId(@Param("userId") int userId);
	 
	@Query(value = "select id from cart where user_id=:userId", nativeQuery=true)
	public static Cart getCartId(@Param("userId") int userId) {
		// TODO Auto-generated method stub
		return null;
	}
  
}
