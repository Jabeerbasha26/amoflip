package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.modal.Cart;
import com.example.demo.repo. CartRepo;


@Service
@Transactional
public class CartService {
	final  CartRepo Cartrepo;
	
	@Autowired
	public CartService( CartRepo  Cartrepo) {
		this.Cartrepo = Cartrepo;

	}
	public List<Cart> getAllCarts() {
		List<Cart> Carts = new ArrayList<Cart>();
		Cartrepo.findAll().forEach(Cart1 -> {
			 Carts.add(Cart1);
		});
		return  Carts;
	}
	public void saveOrUpdate(Cart  Carts) {
		Cartrepo.save(Carts);
	}
	public void delete(int CartId) {
		Cartrepo.deleteById(CartId);
	}
	public Cart getCartById(int CartId) {
		return Cartrepo.findById(CartId).get();
	}

	

}