package com.example.demo.modal;

public class Cart {

}
