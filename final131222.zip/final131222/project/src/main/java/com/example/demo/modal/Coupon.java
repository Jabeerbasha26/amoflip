package com.example.demo.modal;



import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import javax.persistence.CascadeType;

import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


 
@Entity
@Table(name="coupon")
public class Coupon {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int couponId;



    private String couponName;
	
    private String couponCode;
    
    private int discountPrice;
    
    private String expiryDate;
 
    private int eventId;
	
    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "eventId", insertable = false, updatable = false)
	private Event eventDetails;

	public Coupon() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCouponId() {
		return couponId;
	}

	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}

	public String getCouponName() {
		return couponName;
	}

	public void setCouponName(String couponName) {
		this.couponName = couponName;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public int getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(int discountPrice) {
		this.discountPrice = discountPrice;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public Event getEventDetails() {
		return eventDetails;
	}

	public void setEventDetails(Event eventDetails) {
		this.eventDetails = eventDetails;
	}
	
	
	

	


	
	
	
	
    
}
