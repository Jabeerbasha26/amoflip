package com.example.demo.modal;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;





@Entity
@Table(name="event")
public class Event {

	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eventid;
	
	
    private String eventName;
	
	
    private String eventStartDate;
    

    private String eventEndDate;


	public int getEventid() {
		return eventid;
	}


	public void setEventid(int eventid) {
		this.eventid = eventid;
	}


	public String getEventName() {
		return eventName;
	}


	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	public String getEventStartDate() {
		return eventStartDate;
	}


	public void setEventStartDate(String eventStartDate) {
		this.eventStartDate = eventStartDate;
	}


	public String getEventEndDate() {
		return eventEndDate;
	}


	public void setEventEndDate(String eventEndDate) {
		this.eventEndDate = eventEndDate;
	}
    
    
    
	
	
     
	
}
	
   