package com.example.demo.modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;



import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class cartitem {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartitemid;
	
	private int productId;
	
	private String price;
	
	private String productName;

	@Lob
	private String productImage;
	
	public cartitem() {
		super();
		// TODO Auto-generated constructor stub
	}

	public cartitem(int cartitemid, int productId, String price, String productName, String productImage) {
		super();
		this.productImage = productImage;
		this.cartitemid = cartitemid;
		this.productId = productId;
		this.price = price;
		this.productName = productName;
	}
	
	

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public int getCartitemid() {
		return cartitemid;
	}

	public void setCartitemid(int cartitemid) {
		this.cartitemid = cartitemid;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	

	
	
	
}
