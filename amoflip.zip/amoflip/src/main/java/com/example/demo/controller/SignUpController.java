package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.modal.SignUpModal;
import com.example.demo.repo.SignUpRepo;

@CrossOrigin(origins ="null", allowedHeaders = "*")
@RestController
@RequestMapping("/api")
public class SignUpController {
	
	@Autowired
	private SignUpRepo signuprepo;
	
	 @PostMapping("/signuprepo")
	    public SignUpModal createUser(@RequestBody SignUpModal reg) {
	        return signuprepo.save(reg);
	    }
	 @GetMapping("/login")
	    public List < SignUpModal > checkUser() {
	        return signuprepo.findAll();
	    }
	

}
